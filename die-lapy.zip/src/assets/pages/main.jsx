import React from 'react';
import Style from '../styles/section.module.scss'

const MainPage = ({
  second
}) => {
  return (
    <section className={[Style.section,(second)? Style.secondary : Style.primary].join(" ")}>
      <div className={Style.wrapper}>

      </div>
    </section>
  );
};

export default MainPage; 
