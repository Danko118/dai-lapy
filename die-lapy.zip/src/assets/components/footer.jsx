import React from 'react';

const UiFooter = () => {
    return (
        <div>
            
        </div>
    );
};

export default UiFooter;