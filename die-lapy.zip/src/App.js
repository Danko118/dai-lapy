import Style from "./assets/styles/app.module.scss"
import UiHeader from "./assets/components/header";
import MainPage from "./assets/pages/main";
import UiAbout from "./assets/components/about";
import UiNeedo from "./assets/components/needo";

function App() {
  return (
    <div className={Style.app}>
      <UiHeader />
      <MainPage 
        second={false}
      />
      <UiAbout
        second={false}
      />
      <UiNeedo
        second={true}
      />
    </div>
  );
}

export default App;
